package com.example.manogna.contacts_new;

import android.content.ContentProviderOperation;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by manogna on 27-04-2016.
 */
public class StartActivity extends AppCompatActivity {
    public String cont = "{\"contacts\": [{\"email\": \"ramesh.sippi@gmail.com\", \"officePhone\": 80012345676, \"phone\": 9970667543, \"latitude\": 18.5204, \"longitude\": 73.8567, \"name\": \"Ramesh Sippi\"}, {\"email\": \"jack.daniel@gmail.com\", \"officePhone\": 80012345676, \"phone\": 9970967543, \"latitude\": 51.5074, \"longitude\": 0.1278, \"name\": \"Jack daniel\"}, {\"email\": \"steev.jobs@apple.com\", \"officePhone\": 80012345676, \"phone\": 9970967543, \"latitude\": 37.0902, \"longitude\": 95.7129, \"name\": \"Steev Jobs\"}, {\"email\": \"ratan.tata@gmail.com\", \"officePhone\": 80012345676, \"phone\": 9970967543, \"latitude\": 12.9279, \"longitude\": 77.6271, \"name\": \"Ratan Tata\"}, {\"email\": \"robin.pandey@gmail.com\", \"officePhone\": 80012345676, \"phone\": 9970967543, \"latitude\": 12.9279, \"longitude\": 77.6271, \"name\": \"Robin Pandey\"}, {\"email\": \"katrina.kaif@gmail.com\", \"officePhone\": 80012345676, \"phone\": 9970967543, \"latitude\": 12.9279, \"longitude\": 77.6271, \"name\": \"Katrina Kaif\"}, {\"email\": \"prem.chopra@chopra.com\", \"officePhone\": 80012345676, \"phone\": 9970967543, \"latitude\": 12.9279, \"longitude\": 77.6271, \"name\": \"Prem chopra\"}, {\"email\": \"rajnikant@gmail.com\", \"officePhone\": 80012345676, \"phone\": 9970967543, \"latitude\": 12.9279, \"longitude\": 77.6271, \"name\": \"Rajanikant \"}, {\"email\": \"deepika.padukon@gmail.com\", \"officePhone\": 80012345676, \"phone\": 9970967543, \"latitude\": 12.9279, \"longitude\": 77.6271, \"name\": \"Deepika Padukon\"}, {\"email\": \"priyanka.chopra@gmail.com\", \"officePhone\": 80012345676, \"phone\": 9970967543, \"latitude\": 12.9279, \"longitude\": 77.6271, \"name\": \"Priyanka Chopra\"}, {\"latitude\": 12.9279, \"longitude\": 77.6271, \"name\": \"Sonam Gupta\", \"phone\": 9970967543, \"officePhone\": 80012345676}, {\"officePhone\": 80012345676, \"latitude\": 12.9279, \"longitude\": 77.6271, \"name\": \"Kasturi Bhardwaj\", \"email\": \"kasturi.bhardwaj@gmail.com\"}, {\"latitude\": 12.9279, \"longitude\": 76.6271, \"name\": \"Rahaul Kulkarni\", \"phone\": 9970967543, \"email\": \"rahul.kulkarni@gmail.com\"}]}";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);


        Button b1 = (Button) findViewById(R.id.b1);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(StartActivity.this, ShowContactsActivity.class);
                startActivity(intent);
            }
        });

        Button b2 = (Button) findViewById(R.id.b2);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(StartActivity.this, MapsActivity.class);
                startActivity(intent);
            }
        });

        Toast.makeText(this, "Please wait while contacts are synced", Toast.LENGTH_LONG).show();
        new SyncContacts().execute();
    }


    class SyncContacts extends AsyncTask<String,String,String>
    {
        private static final String TAG = " ";

        @Override
        protected String doInBackground(String... params)
        {
            /*String JsonResponse = null;

            HttpURLConnection connection = null;
            BufferedReader reader = null;
            try
            {
                URL url = new URL("http://private-b08d8d-nikitest.apiarymock.com/contacts");
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                //connection.setRequestProperty("Content-Type", "application/json");
                //connection.setRequestProperty("Accept", "application/json");
                connection.connect();

                int errorCode = connection.getResponseCode(); System.out.println("GetErrorStream " + errorCode);

                InputStream inputStream = connection.getInputStream();
                StringBuffer buffer = new StringBuffer();
                if (inputStream == null) {
                    return null;
                }
                reader = new BufferedReader(new InputStreamReader(inputStream));

                String inputLine;
                while ((inputLine = reader.readLine()) != null)
                    buffer.append(inputLine + "\n");
                if (buffer.length() == 0)
                {
                    return null;
                }
                JsonResponse = buffer.toString();
                Log.i(TAG, JsonResponse);
                System.out.println("response: "+JsonResponse);
                return JsonResponse;

            }

            catch (IOException e)
            {
                e.printStackTrace();
            }
            finally
            {
                if (connection != null)
                {
                    connection.disconnect();
                }
                if (reader != null)
                {
                    try
                    {
                        reader.close();
                    } catch (final IOException e)
                    {
                        Log.e(TAG, "Error closing stream", e);
                    }
                }
            }
            */
            try {
                System.out.println("Entering...");
                JSONObject jsonRootObject = new JSONObject(cont);

                //Get the instance of JSONArray that contains JSONObjects
                JSONArray jsonArray = jsonRootObject.optJSONArray("contacts");

                //float latitude, longitude;
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);

                    //latitude = Float.parseFloat(jsonObject.optString("latitude").toString());
                    //longitude = Float.parseFloat(jsonObject.optString("longitude").toString());
                    String name = jsonObject.optString("name").toString();
                    String email = jsonObject.optString("email").toString();
                    String phone = jsonObject.optString("phone").toString();
                    String officePhone = jsonObject.optString("officePhone").toString();

                    ArrayList<ContentProviderOperation> ops = new ArrayList<ContentProviderOperation>();

                    ops.add(ContentProviderOperation.newInsert(
                            ContactsContract.RawContacts.CONTENT_URI)
                            .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
                            .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null)
                            .build());


                    if (name != null) {
                        ops.add(ContentProviderOperation.newInsert(
                                ContactsContract.Data.CONTENT_URI)
                                .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                                .withValue(ContactsContract.Data.MIMETYPE,
                                        ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
                                .withValue(
                                        ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME,
                                        name).build());
                    }

                    if (phone != null) {
                        ops.add(ContentProviderOperation.
                                newInsert(ContactsContract.Data.CONTENT_URI)
                                .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                                .withValue(ContactsContract.Data.MIMETYPE,
                                        ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                                .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, phone)
                                .withValue(ContactsContract.CommonDataKinds.Phone.TYPE,
                                        ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE)
                                .build());
                    }


                    if (officePhone != null) {
                        ops.add(ContentProviderOperation.
                                newInsert(ContactsContract.Data.CONTENT_URI)
                                .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                                .withValue(ContactsContract.Data.MIMETYPE,
                                        ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                                .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, officePhone)
                                .withValue(ContactsContract.CommonDataKinds.Phone.TYPE,
                                        ContactsContract.CommonDataKinds.Phone.TYPE_WORK)
                                .build());
                    }

                    if (email != null) {
                        ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                                .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                                .withValue(ContactsContract.Data.MIMETYPE,
                                        ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE)
                                .withValue(ContactsContract.CommonDataKinds.Email.DATA, email)
                                .withValue(ContactsContract.CommonDataKinds.Email.TYPE, ContactsContract.CommonDataKinds.Email.TYPE_WORK)
                                .build());
                    }

                    try {
                        getContentResolver().applyBatch(ContactsContract.AUTHORITY, ops);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(StartActivity.this, "Exception: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }
            catch (JSONException e)
            {
                e.printStackTrace();
            }

            return null;

        }


        @Override
        protected void onPostExecute(String s)
        {
            Toast.makeText(StartActivity.this, "Contacts synced", Toast.LENGTH_LONG).show();
        }

    }
}
