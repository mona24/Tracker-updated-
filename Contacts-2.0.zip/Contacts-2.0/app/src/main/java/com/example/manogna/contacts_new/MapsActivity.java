package com.example.manogna.contacts_new;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback, GoogleMap.OnMarkerClickListener{

    public GoogleMap mMap;
    public String cont = "{\"contacts\": [{\"email\": \"ramesh.sippi@gmail.com\", \"officePhone\": 80012345676, \"phone\": 9970667543, \"latitude\": 18.5204, \"longitude\": 73.8567, \"name\": \"Ramesh Sippi\"}, {\"email\": \"jack.daniel@gmail.com\", \"officePhone\": 80012345676, \"phone\": 9970967543, \"latitude\": 51.5074, \"longitude\": 0.1278, \"name\": \"Jack daniel\"}, {\"email\": \"steev.jobs@apple.com\", \"officePhone\": 80012345676, \"phone\": 9970967543, \"latitude\": 37.0902, \"longitude\": 95.7129, \"name\": \"Steev Jobs\"}, {\"email\": \"ratan.tata@gmail.com\", \"officePhone\": 80012345676, \"phone\": 9970967543, \"latitude\": 12.9279, \"longitude\": 77.6271, \"name\": \"Ratan Tata\"}, {\"email\": \"robin.pandey@gmail.com\", \"officePhone\": 80012345676, \"phone\": 9970967543, \"latitude\": 12.9279, \"longitude\": 77.6271, \"name\": \"Robin Pandey\"}, {\"email\": \"katrina.kaif@gmail.com\", \"officePhone\": 80012345676, \"phone\": 9970967543, \"latitude\": 12.9279, \"longitude\": 77.6271, \"name\": \"Katrina Kaif\"}, {\"email\": \"prem.chopra@chopra.com\", \"officePhone\": 80012345676, \"phone\": 9970967543, \"latitude\": 12.9279, \"longitude\": 77.6271, \"name\": \"Prem chopra\"}, {\"email\": \"rajnikant@gmail.com\", \"officePhone\": 80012345676, \"phone\": 9970967543, \"latitude\": 12.9279, \"longitude\": 77.6271, \"name\": \"Rajanikant \"}, {\"email\": \"deepika.padukon@gmail.com\", \"officePhone\": 80012345676, \"phone\": 9970967543, \"latitude\": 12.9279, \"longitude\": 77.6271, \"name\": \"Deepika Padukon\"}, {\"email\": \"priyanka.chopra@gmail.com\", \"officePhone\": 80012345676, \"phone\": 9970967543, \"latitude\": 12.9279, \"longitude\": 77.6271, \"name\": \"Priyanka Chopra\"}, {\"latitude\": 12.9279, \"longitude\": 77.6271, \"name\": \"Sonam Gupta\", \"phone\": 9970967543, \"officePhone\": 80012345676}, {\"officePhone\": 80012345676, \"latitude\": 12.9279, \"longitude\": 77.6271, \"name\": \"Kasturi Bhardwaj\", \"email\": \"kasturi.bhardwaj@gmail.com\"}, {\"latitude\": 12.9279, \"longitude\": 76.6271, \"name\": \"Rahaul Kulkarni\", \"phone\": 9970967543, \"email\": \"rahul.kulkarni@gmail.com\"}]}";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setOnMarkerClickListener((GoogleMap.OnMarkerClickListener)this);

        try
        {
            System.out.println("Entering...");
            JSONObject  jsonRootObject = new JSONObject(cont);

            //Get the instance of JSONArray that contains JSONObjects
            JSONArray jsonArray = jsonRootObject.optJSONArray("contacts");

            float latitude, longitude;
            LatLng location = null;

            //Iterate the jsonArray and print the info of JSONObjects
            for(int i=0; i < jsonArray.length(); i++)
            {
                JSONObject jsonObject = jsonArray.getJSONObject(i);

                System.out.println("Testing...");
                System.out.println(jsonObject);

                latitude = Float.parseFloat(jsonObject.optString("latitude").toString());
                longitude = Float.parseFloat(jsonObject.optString("longitude").toString());
                String name = jsonObject.optString("name").toString();
                String email = jsonObject.optString("email").toString();
                String phone = jsonObject.optString("phone").toString();
                String officePhone = jsonObject.optString("officePhone").toString();

                location = new LatLng(latitude, longitude);
                mMap.addMarker(new MarkerOptions().position(location).title(name).snippet("Email: " + email + "\n" + "Phone: " + phone + "\n" + "Office Phone: " + officePhone));
                //mMap.moveCamera(CameraUpdateFactory.newLatLng(location));
            }
            mMap.moveCamera(CameraUpdateFactory.newLatLng(location));
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }

    }


    @Override
    public boolean onMarkerClick(Marker marker)
    {
        //System.out.println(marker.getTitle());

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);

        String message = marker.getTitle() + "\n" + marker.getSnippet();

        final TextView textView = new TextView(this);
        textView.setTextSize(25);
        textView.setText(message);

        // set prompts.xml to alertdialog builder
        alertDialogBuilder.setView(textView);

        // set dialog message
        alertDialogBuilder.setCancelable(false).setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            }
        });

        // create alert dialog
        AlertDialog alertDialog = alertDialogBuilder.create();
        // show it
        alertDialog.show();
        return false;
    }
}
