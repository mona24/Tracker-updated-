package com.example.manogna.contacts_new;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by manogna on 27-04-2016.
 */
public class ShowContactsActivity extends AppCompatActivity {

    public String cont = "{\"contacts\": [{\"email\": \"ramesh.sippi@gmail.com\", \"officePhone\": 80012345676, \"phone\": 9970667543, \"latitude\": 18.5204, \"longitude\": 73.8567, \"name\": \"Ramesh Sippi\"}, {\"email\": \"jack.daniel@gmail.com\", \"officePhone\": 80012345676, \"phone\": 9970967543, \"latitude\": 51.5074, \"longitude\": 0.1278, \"name\": \"Jack daniel\"}, {\"email\": \"steev.jobs@apple.com\", \"officePhone\": 80012345676, \"phone\": 9970967543, \"latitude\": 37.0902, \"longitude\": 95.7129, \"name\": \"Steev Jobs\"}, {\"email\": \"ratan.tata@gmail.com\", \"officePhone\": 80012345676, \"phone\": 9970967543, \"latitude\": 12.9279, \"longitude\": 77.6271, \"name\": \"Ratan Tata\"}, {\"email\": \"robin.pandey@gmail.com\", \"officePhone\": 80012345676, \"phone\": 9970967543, \"latitude\": 12.9279, \"longitude\": 77.6271, \"name\": \"Robin Pandey\"}, {\"email\": \"katrina.kaif@gmail.com\", \"officePhone\": 80012345676, \"phone\": 9970967543, \"latitude\": 12.9279, \"longitude\": 77.6271, \"name\": \"Katrina Kaif\"}, {\"email\": \"prem.chopra@chopra.com\", \"officePhone\": 80012345676, \"phone\": 9970967543, \"latitude\": 12.9279, \"longitude\": 77.6271, \"name\": \"Prem chopra\"}, {\"email\": \"rajnikant@gmail.com\", \"officePhone\": 80012345676, \"phone\": 9970967543, \"latitude\": 12.9279, \"longitude\": 77.6271, \"name\": \"Rajanikant \"}, {\"email\": \"deepika.padukon@gmail.com\", \"officePhone\": 80012345676, \"phone\": 9970967543, \"latitude\": 12.9279, \"longitude\": 77.6271, \"name\": \"Deepika Padukon\"}, {\"email\": \"priyanka.chopra@gmail.com\", \"officePhone\": 80012345676, \"phone\": 9970967543, \"latitude\": 12.9279, \"longitude\": 77.6271, \"name\": \"Priyanka Chopra\"}, {\"latitude\": 12.9279, \"longitude\": 77.6271, \"name\": \"Sonam Gupta\", \"phone\": 9970967543, \"officePhone\": 80012345676}, {\"officePhone\": 80012345676, \"latitude\": 12.9279, \"longitude\": 77.6271, \"name\": \"Kasturi Bhardwaj\", \"email\": \"kasturi.bhardwaj@gmail.com\"}, {\"latitude\": 12.9279, \"longitude\": 76.6271, \"name\": \"Rahaul Kulkarni\", \"phone\": 9970967543, \"email\": \"rahul.kulkarni@gmail.com\"}]}";
    public ArrayList<String> names;
    public ArrayList<String> phones;
    public ArrayList<String> officePhones;
    public ArrayList<String> emails;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show);
        try
        {
            System.out.println("Entering...");
            JSONObject jsonRootObject = new JSONObject(cont);

            //Get the instance of JSONArray that contains JSONObjects
            JSONArray jsonArray = jsonRootObject.optJSONArray("contacts");

            for(int i=0; i < jsonArray.length(); i++)
            {
                JSONObject jsonObject = jsonArray.getJSONObject(i);

                String name = jsonObject.optString("name").toString();
                String email = jsonObject.optString("email").toString();
                String phone = jsonObject.optString("phone").toString();
                String officePhone = jsonObject.optString("officePhone").toString();

                names.add(name);
                phones.add(phone);
                officePhones.add(officePhone);
                emails.add(email);

            }

        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }

        CustomView adapter = new CustomView(ShowContactsActivity.this, names, phones, officePhones, emails);
        ListView list = (ListView)findViewById(R.id.list);
        list.setAdapter(adapter);

    }
}
