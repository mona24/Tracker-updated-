package com.example.manogna.contacts_new;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by manogna on 27-04-2016.
 */
public class CustomView extends BaseAdapter {
    private Context mContext;
    public ArrayList<String> names;
    public ArrayList<String> phones;
    public ArrayList<String> officePhones;
    public ArrayList<String> emails;

    public CustomView(Context c, ArrayList<String> names,ArrayList<String> phones, ArrayList<String> officePhones, ArrayList<String> emails) {
        mContext = c;
        this.names = new ArrayList<String>(names);
        this.phones = new ArrayList<String>(phones);
        this.officePhones = new ArrayList<String>(officePhones);
        this.emails = new ArrayList<String>(emails);
    }

    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return 10;
    }

    @Override
    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // TODO Auto-generated method stub
        View list;
        LayoutInflater inflater = (LayoutInflater) mContext
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        if (convertView == null) {

            list = new View(mContext);
            list = inflater.inflate(R.layout.list_single, null);
            TextView name = (TextView) list.findViewById(R.id.name);
            TextView phone = (TextView) list.findViewById(R.id.phone);
            TextView officePhone = (TextView) list.findViewById(R.id.officePhone);
            TextView email = (TextView) list.findViewById(R.id.email);

            name.setText(names.get(position));
            phone.setText(phones.get(position));
            officePhone.setText(officePhones.get(position));
            email.setText(emails.get(position));
        }
        else {
            list = (View) convertView;
        }

        return list;
    }
}
